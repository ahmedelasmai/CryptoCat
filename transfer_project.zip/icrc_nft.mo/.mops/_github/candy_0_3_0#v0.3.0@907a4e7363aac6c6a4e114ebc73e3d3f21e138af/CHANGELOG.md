v0.3.0

- Added the ValueShared type for dumping a Candy and CandyShared to an ICRC3 style Value type.
- Added many tests.