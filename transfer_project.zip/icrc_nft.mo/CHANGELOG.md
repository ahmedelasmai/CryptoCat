# Changelog


# v0.2.2

Update mops for ICRC-7 and ICRC-37 to fix token_of bug https://github.com/PanIndustrial-Org/icrc_nft.mo/issues/3


# v0.1.1

Update mops

# v0.1.0

Initial Release